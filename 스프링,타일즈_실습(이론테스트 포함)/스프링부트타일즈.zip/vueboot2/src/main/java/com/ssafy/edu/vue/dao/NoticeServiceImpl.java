package com.ssafy.edu.vue.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ssafy.edu.vue.dto.Notices;

@Service
public class NoticeServiceImpl implements INoticeService {
	
    @Autowired
	private NoticeDaoImpl noticedao;
	
	@Override
	@Transactional(readOnly=true)
	public List<Notices> getNoticeList() {
		return noticedao.getNoticeList();
	}

	@Override
	@Transactional(readOnly=true)
	public Notices getNotice(int seq) {
		return noticedao.getNotice(seq);
	}

	@Override
	@Transactional
	public void updatenotice(Notices b) {
		noticedao.updatenotice(b);
	}

	@Override
	@Transactional
	public void savenotice(Notices b) {
		noticedao.savenotice(b);
	}

	@Override
	@Transactional
	public void noticedelete(Notices b) {
		noticedao.noticedelete(b);
	}

}
