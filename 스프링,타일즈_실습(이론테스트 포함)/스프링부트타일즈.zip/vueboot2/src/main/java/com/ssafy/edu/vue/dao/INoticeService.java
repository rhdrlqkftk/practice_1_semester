package com.ssafy.edu.vue.dao;

import java.util.List;

import com.ssafy.edu.vue.dto.Notices;


public interface INoticeService {
	public List<Notices> getNoticeList ();
	public Notices getNotice(int seq) ;
	public void updatenotice(Notices b);
	public void savenotice(Notices b) ;
	public void noticedelete(Notices b) ;
}
