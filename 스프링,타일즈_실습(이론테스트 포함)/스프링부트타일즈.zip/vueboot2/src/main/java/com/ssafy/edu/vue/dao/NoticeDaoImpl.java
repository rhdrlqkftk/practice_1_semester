package com.ssafy.edu.vue.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.edu.vue.dto.Notices;

@Repository
public class NoticeDaoImpl {
	
	String ns="ssafy.notices.";
	@Autowired
	private SqlSession sqlSession;
	
	public List<Notices> getNoticeList (){
		return sqlSession.selectList(ns+"getNoticeList");
	}
	public Notices getNotice(int seq) {
		return sqlSession.selectOne(ns+"getNotice",seq);
	}
	public void updatenotice(Notices b) {
		sqlSession.update(ns+"updatenotice",b);
	}
	public void savenotice(Notices b) {
		sqlSession.insert(ns+"savenotice",b);
	}
	public void noticedelete(Notices b) {
		sqlSession.delete(ns+"noticedelete",b);
	}
}
