package com.ssafy.edu.vue.dto;

import java.io.Serializable;
//com.ssafy.edu.vue.dto.Notices
public class Notices implements Serializable{
	private int seq;
	private String writer;
	private String title;
	private String wdate;
	private String wcontents;
	public Notices() {
		super();
	}
	public Notices(int seq, String writer, String title, String wdate, String wcontents) {
		super();
		this.seq = seq;
		this.writer = writer;
		this.title = title;
		this.wdate = wdate;
		this.wcontents = wcontents;
	}
	@Override
	public String toString() {
		return "Notices [seq=" + seq + ", writer=" + writer + ", title=" + title + ", wdate=" + wdate + ", wcontents="
				+ wcontents + "]";
	}
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWdate() {
		return wdate;
	}
	public void setWdate(String wdate) {
		this.wdate = wdate;
	}
	public String getWcontents() {
		return wcontents;
	}
	public void setWcontents(String wcontents) {
		this.wcontents = wcontents;
	}
}
/*
  `seq` INT NOT NULL AUTO_INCREMENT,
  `writer` VARCHAR(50) NOT NULL,
  `title` VARCHAR(100) NOT NULL,
  `wdate` DATE NOT NULL,
  `wcontents` VARCHAR(2000) NOT NULL,
*/