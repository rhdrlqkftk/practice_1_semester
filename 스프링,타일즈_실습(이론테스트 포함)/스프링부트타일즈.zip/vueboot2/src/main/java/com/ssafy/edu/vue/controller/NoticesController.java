package com.ssafy.edu.vue.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dao.INoticeService;
import com.ssafy.edu.vue.dto.DepCountDto;
import com.ssafy.edu.vue.dto.DepartmentDto;
import com.ssafy.edu.vue.dto.DepartmentEmpDto;
import com.ssafy.edu.vue.dto.DeptEmpsDto;
import com.ssafy.edu.vue.dto.EmployeeDto;
import com.ssafy.edu.vue.dto.EmployeeDto2;
import com.ssafy.edu.vue.dto.Notices;
import com.ssafy.edu.vue.help.BoolResult;
import com.ssafy.edu.vue.help.NumberResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

//http://localhost:8197/humans/swagger-ui.html
@CrossOrigin(origins = {"*"}, maxAge = 6000) 
// jsp같은 html만드는 녀석은 server에 있다. 비동기는 서버에 데이터를 화면에서 조립해야한다. -이럴 때는 영역이 다르다고 해서  막아버리는데 이를 crossorign으로 풀어준다. db단에 따라서 4가지(get,post,put,delete)  
// 비동기에서 가장 큰 문제는 크로스 오리진 문제
@RestController
// 비동기 rest를 만들어주는 녀석. 원래는 @ResponseBody // 로그인 시에 이렇게 받았지만 restful에서는 그렇게 안함.
@RequestMapping("/api")
@Api(value="SSAFY", description="SSAFY Resouces Management 2019")
public class NoticesController {
	
	public static final Logger logger = LoggerFactory.getLogger(NoticesController.class);
	
	@Autowired
	private INoticeService noticeService; 
	
    @ApiOperation(value = "모든 알림글을 반환한다.", response = List.class)
	@RequestMapping(value = "/getNoticeList", method = RequestMethod.GET)
	public ResponseEntity<List<Notices>> getNoticeList() throws Exception {
		logger.info("1-------------findAllEmployees-----------------------------"+new Date());
		List<Notices> emps = noticeService.getNoticeList();
		if (emps.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Notices>>(emps, HttpStatus.OK);
	}
    
    @ApiOperation(value = "해당 알림글을 반환한다.", response = Notices.class)
	@RequestMapping(value = "/getNotice/{seq}", method = RequestMethod.GET)
	public ResponseEntity<Notices> getNotice(@PathVariable int seq) throws Exception {
		logger.info("1-------------findAllEmployees-----------------------------"+new Date());
		Notices emps = noticeService.getNotice(seq);
		if(emps ==null || emps.getSeq()==0)
		{
			return new ResponseEntity<Notices>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<Notices>(emps, HttpStatus.OK);
	}
    /*
    @ApiOperation(value = "해당 알림글을 반환한다.", response = Notices.class)
    @RequestMapping(value = "noticelist.do", 
			method = RequestMethod.GET)
	public String noticelist(Model model) {
		logger.info("Welcome NoticeController noticelist! "+ new Date());
		model.addAttribute("notices", noticeservice.getNoticeList());
		model.addAttribute("doc_title", "SSAFY Notice");
		return "notices.tiles";
	}//	
*/	
}
