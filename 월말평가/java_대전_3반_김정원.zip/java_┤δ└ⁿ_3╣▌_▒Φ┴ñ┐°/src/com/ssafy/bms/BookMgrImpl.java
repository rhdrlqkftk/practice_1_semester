package com.ssafy.bms;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.nio.ReadOnlyBufferException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class BookMgrImpl implements IBookMgr {
	private ArrayList<Book> books = new ArrayList<>();
	private static BookMgrImpl mgr = new BookMgrImpl();
	static public BookMgrImpl getInstance()
	{
		return mgr;
	}
	private Book findByIsbn(String s)
	{
		Book t = null;
		for( Book k: books )
		{
			if(k.getIsbn().equals(s))
			{
				t =k;
				break;
			}
		}
		return t; 
	}
	@Override
	public void load() 
	{
		String fbook = "data.dat";
		File boo = new File(fbook);
		if(!boo.exists())
		{
			return ; 
		}
		books.clear(); 
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream( new FileInputStream(boo));
			int cnt = ois.readInt();
			for (int i = 0; i < cnt; i++) 
			{
				Book k = (Book)ois.readObject(); 
				books.add(k);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ; 		
	}
	@Override
	public void save() 
	{
		String fbook = "data.dat";
		File boo = new File(fbook);
		if(!boo.exists())
		{
			try {
				boo.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		ObjectOutput oos = null;  
		try {
			oos = new ObjectOutputStream(new FileOutputStream(boo,false));
			oos.writeInt(books.size());
			for (Book k :books)
			{
				oos.writeObject(k);
				oos.flush(); 
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				oos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
	}
	@Override
	public void add(Book b) throws DuplicateException {
	 // book b가  들어왔어 어떻게 할래? // 있는지 없는지 isbn으로 확인해도되지. 
		Book t = findByIsbn(b.getIsbn());
		if( t == null)
		{
			books.add(b);
		}
		else
		{
			throw new DuplicateException();
		}	
	}

	@Override
	public List<Book> search() {
		// TODO Auto-generated method stub	
		return books;
	}

	@Override
	public Book search(String isbn) throws RecordNotFoundException {
		Book k = findByIsbn(isbn);
		if( k != null)
		{
			return k;	
		}
		else
		{
			throw new RecordNotFoundException();
		}
	}

	@Override
	public void update(String isbn, int price) throws RecordNotFoundException {
		//파라미터에 전달된 도시 번호로 정보를 찾아서 리턴한다.  
		Book k = findByIsbn(isbn);
		if( k != null)
		{
			k.setPrice(price);			
		}
		else 
		{
			throw new RecordNotFoundException();
		}
	}

	@Override
	public void delete(String isbn) throws RecordNotFoundException 
	{
		int flag=0;
		int cnt = books.size();
		for(int i=0;i<cnt;i++)
		{
			if(books.get(i).getIsbn().equals(isbn))
			{
				flag =1;
				books.remove(books.get(i));
			}
		}
		if( flag==0)
		{
			throw new RecordNotFoundException();
		}

	}	
	@Override
	public List<Book> searchTitle(String title) 
	{
		List<Book> d = new ArrayList<>();
		for(Book xx : books)
		{
			if( xx.getTitle().contains(title) )
			{
				d.add(xx);	
			}
		}
		return d;
	}

	@Override
	public List<Book> sortIsbn() {
		books.sort(new Comparator<Book>() 
		{
			@Override
			public int compare(Book b1, Book b2) 
			{
				return b1.getIsbn().compareTo(b2.getIsbn());
			}
		});
		return books;
	}
	@Override
	public String countWord() 
	{
	// TODO Auto-generated method stub
		return null;
	}

}
