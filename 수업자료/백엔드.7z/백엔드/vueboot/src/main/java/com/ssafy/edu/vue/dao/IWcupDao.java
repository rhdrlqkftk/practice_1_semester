package com.ssafy.edu.vue.dao;

import java.util.List;
import com.ssafy.edu.vue.dto.WorldCup;

public interface IWcupDao 
{
	public List<WorldCup> findAllWorldCups()throws Exception;
	public List<WorldCup> priorQueue()throws Exception;
	public void addWin(String name) throws Exception;
	public int totalCount() throws Exception; 
}
