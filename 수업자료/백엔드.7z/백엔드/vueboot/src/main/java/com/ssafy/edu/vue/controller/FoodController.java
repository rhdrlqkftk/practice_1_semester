package com.ssafy.edu.vue.controller;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dto.Food;
import com.ssafy.edu.vue.dto.Notice;
import com.ssafy.edu.vue.help.NumberResult;
import com.ssafy.edu.vue.service.IFoodService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


@CrossOrigin(origins = {"*"}, maxAge = 6000)             // 크로싱 브라우져,... 
@RestController
@RequestMapping("/api")
@Api(value="SSAFY", description="SSAFY Resouces Management 2019")		//스웨거 
public class FoodController {
	private static final Logger logger = LoggerFactory.getLogger(FoodController.class);
	@Autowired
	private IFoodService foodservice;
	
	@ApiOperation(value = "모든 음식 정보를 반환한다.", response = List.class)
	@RequestMapping(value = "/findAllFoods", method = RequestMethod.GET)
	public ResponseEntity<List<Food>> index() throws Exception 
	{
		logger.debug("Welcome FoodController index! " + new Date());
		List<Food> foods= foodservice.findAllFoods();
		if (foods.isEmpty()) {
			return new ResponseEntity<List<Food>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Food>>(foods, HttpStatus.OK);
	}
	@ApiOperation(value = "Id로 찾기", response = NumberResult.class)
	@RequestMapping(value = "/findAllFoodById/{foodId}", 
			method = {RequestMethod.GET})
    public ResponseEntity<Food> findAllFoodById(@PathVariable String foodId) throws Exception
    {	
		Food foods =foodservice.findFoodById(foodId);
		if (foods == null) 
		{
			return new ResponseEntity<Food>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<Food>(foods, HttpStatus.OK);
	}
	@ApiOperation(value = "이름으로 찾기", response = List.class)
	@RequestMapping(value = "/findAllFoodByName/{foodName}", method = {RequestMethod.GET})
	public ResponseEntity<List<Food>> findAllFoodByName(@PathVariable String foodName) throws Exception
	{ 
		List<Food>  foods = foodservice.searchFoods(foodName);
		if (foods.isEmpty()) {
			return new ResponseEntity<List<Food>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Food>>(foods, HttpStatus.OK);
	}
	
	@ApiOperation(value = "detail", response = NumberResult.class)
	@RequestMapping(value = "/FoodDetail/{code}", method = {RequestMethod.GET})
    public ResponseEntity<Food> FoodDetail(@PathVariable String code) throws Exception
    {	
		logger.debug("Welcome FoodController detail! " + new Date());
		Food food =foodservice.findFoodById(code);
		if (food == null) 
		{
			return new ResponseEntity<Food>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<Food>(food, HttpStatus.OK);
	}
}
