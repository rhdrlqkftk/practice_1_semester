package com.ssafy.edu.vue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.edu.vue.dao.QnaDaoImpl;
import com.ssafy.edu.vue.dto.Qna;

@Service
public class QnaService implements IQnaService {
	
    @Autowired
	private QnaDaoImpl qnadao;
	
    @Override
	public boolean saveQna(Qna b) throws Exception {
		return qnadao.saveQna(b);
	}
    @Override
	public List<Qna> getQnaList(int memid) throws Exception {
		return qnadao.getQnaList(memid);
	}
	@Override
	public boolean qnadelete(int Id) throws Exception {
		System.out.println("step2-2");
		return qnadao.qnadelete(Id);
		
	}
	@Override
	public boolean qnadelete2(int Id) throws Exception {
		System.out.println("333");
		return qnadao.qnadelete2(Id);
		
	}
	@Override
	public Qna getQna(int num) throws Exception {
		// TODO Auto-generated method stub
		return qnadao.getQna(num);
	}
	@Override
	public boolean updateQna(Qna b) throws Exception {
		// TODO Auto-generated method stub
		return qnadao.updateQna(b);
	}
	
	///////

    /*
	@Override
	@Transactional(readOnly=true)
	public Qna getQna(int num) throws Exception{
		return qnadao.getQna(num);
	}
	@Override
	@Transactional
	public boolean Qnadelete(int num) throws Exception {
		return qnadao.Qnadelete(num);
	}
	@Override
	@Transactional
	public boolean updateQna(Qna b) {
		return qnadao.updateQna(b);
	}*/


	
}
