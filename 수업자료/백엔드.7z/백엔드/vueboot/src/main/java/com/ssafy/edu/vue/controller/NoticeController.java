package com.ssafy.edu.vue.controller;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dto.Notice;
import com.ssafy.edu.vue.dto.Qna;
import com.ssafy.edu.vue.help.BoolResult;
import com.ssafy.edu.vue.help.NumberResult;
import com.ssafy.edu.vue.service.INoticeService;
import com.ssafy.edu.vue.service.IQnaService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = {"*"}, maxAge = 6000)             // 크로싱 브라우져,... 
@RestController
@RequestMapping("/api")
@Api(value="SSAFY", description="SSAFY Resouces Management 2019")		//스웨거 
public class NoticeController {
	private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);

	@Autowired
	private INoticeService noticeservice;
	@Autowired
	private IQnaService qnaservice;
	
    @ApiOperation(value = "모든 공지의 정보를 반환한다.", response = List.class)
	@RequestMapping(value = "/findAllNotice", method = RequestMethod.GET)
	public  ResponseEntity<List<Notice>> index()throws Exception 
    {
		logger.debug("Welcome NoticeController index! " + new Date());
		System.out.println("chk");
		
		List<Notice> notices =noticeservice.getNoticeList();
		if (notices.isEmpty()) {
			return new ResponseEntity<List<Notice>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Notice>>(notices, HttpStatus.OK);
	}
    @ApiOperation(value = "상세보기.", response = NumberResult.class)
	@RequestMapping(value = "/noticedetail/{memId}", 
			method = {RequestMethod.GET})
    public ResponseEntity<Notice> noticedetail(@PathVariable int memId) throws Exception
    {
		logger.debug("Welcome MainController bookdetail! "+ new Date());
		//return "forward:/index";
		Notice noti= noticeservice.getNotice(memId);
		
		System.out.println(noti);
		if (noti==null || noti.getNoticenum()==0) {
			return new ResponseEntity<Notice>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<Notice>(noti, HttpStatus.OK);	
	}
    
	@ApiOperation(value = " 해당메모의 정보를 삭제한다.",response = BoolResult.class)
	@RequestMapping(value = "/noticedelete/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<BoolResult> noticedelete(@PathVariable int id) throws Exception{
		System.out.println("아니냐"+id);
   		BoolResult nr=new BoolResult();
   		System.out.println("step2");
   		boolean ttt =false;
		ttt = qnaservice.qnadelete2(id);
		System.out.println("step3");
		noticeservice.noticedelete(id);
		System.out.println("step4");
		nr.setCount(true);
		nr.setName("good");
		nr.setState("succ");
		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
	}
	@ApiOperation(value = " 새로운 공지를 입력한다.", response = BoolResult.class)
   	@RequestMapping(value = "/addNotice", method = RequestMethod.POST)
   	public ResponseEntity<BoolResult> addNotice(@RequestBody Notice dd) throws Exception 
	{
   		boolean total = noticeservice.savenotice(dd);
   		BoolResult nr=new BoolResult();
   		if (!total) {
			return new ResponseEntity<BoolResult>(HttpStatus.NO_CONTENT);
		}
   		nr.setState("succ");
   		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
   	}
	@ApiOperation(value = " 공지를업데이트합니다.", response = BoolResult.class)
   	@RequestMapping(value = "/updateNotice", method = RequestMethod.POST)
   	public ResponseEntity<BoolResult> updateNotice(@RequestBody Notice dd) throws Exception 
	{
		
   		boolean total = noticeservice.updatenotice(dd);;
   		BoolResult nr=new BoolResult();
   		if (!total) {
			return new ResponseEntity<BoolResult>(HttpStatus.NO_CONTENT);
		}
   		nr.setState("succ");
   		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
   	}
	
		@ApiOperation(value = "모든 공지의 정보를 반환한다.", response = List.class)
		@RequestMapping(value = "/findAllNoticeByname/{name}", method = RequestMethod.GET)
		public  ResponseEntity<List<Notice>> Byname(@PathVariable String name)throws Exception 
	    {
		 	System.out.println(name);
			List<Notice> notices =noticeservice.getByname(name);
			System.out.println(notices);
			if (notices.isEmpty()) {
				return new ResponseEntity<List<Notice>>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<List<Notice>>(notices, HttpStatus.OK);
		}
		@ApiOperation(value = "제목으로 검색.", response = List.class)
		@RequestMapping(value = "/findAllNoticeByTitle/{title}", method = RequestMethod.GET)
		public  ResponseEntity<List<Notice>> ByTitle(@PathVariable String title)throws Exception 
	    {
		 	System.out.println(title);
			List<Notice> notices =noticeservice.getByTitle(title);
			System.out.println(notices);
			if (notices.isEmpty()) {
				return new ResponseEntity<List<Notice>>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<List<Notice>>(notices, HttpStatus.OK);
		}
	
}
