package com.ssafy.edu.vue.dto;
import java.io.Serializable;
public class Member implements Serializable {
	private String id;
	private String pwd;
	private String name;
	private String phone;
	private String alergic;
	private int delflag=0;
	
	public Member() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getAlergic() {
		return alergic;
	}

	public void setAlergic(String alergic) {
		this.alergic = alergic;
	}

	public Member(String id, String pwd, String name, String phone,String alergic) {
		super();
		this.id = id;
		this.pwd = pwd;
		this.name = name;
		this.phone = phone;
		this.alergic = alergic;
	}
	public Member(String id, String pwd) {
		this.id=id;
		this.pwd=pwd;
	}
	
	public Member(String id, String pwd, String name, String phone, String alergic,int delflag) {
		super();
		this.id = id;
		this.pwd = pwd;
		this.name = name;
		this.phone = phone;
		this.alergic = alergic;
		this.delflag = delflag;
	}
	public Member(String id, String name, String phone,String alergic) {
		super();
		this.id = id;
		this.name = name;
		this.phone = phone;
		this.alergic = alergic;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public int getDelflag() {
		return delflag;
	}
	public void setDelflag(int delflag) {
		this.delflag = delflag;
	}
	@Override
	public String toString() {
		return "Member [id=" + id + ", pwd=" + pwd + ", name=" + name + ", phone=" + phone + ", alergic=" + alergic
				+ ", delflag=" + delflag + "]";
	}
}
