package com.ssafy.edu.vue.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ssafy.edu.vue.dao.ISearchRateDao;
import com.ssafy.edu.vue.dto.SearchRate;
@Service
public class SearchRateService implements ISearchRateService {
	@Autowired
	private ISearchRateDao dao;
	
	@Override
	@Transactional(readOnly=true)
	public List<SearchRate> getrate(int categori)throws Exception {
		return dao.getrate(categori);
	}
	
	@Override
	public void search(String keyword, String index)throws Exception  {
		dao.search(keyword, index); 
		
	}
	@Override
	public String getcount(String keyword, String index) throws Exception {
		// TODO Auto-generated method stub
		return dao.getcount(keyword, index);
	}
	@Override
	public void upcount(String keyword, String index, int count)throws Exception  {
		dao.upcount(keyword, index,count);
	}
}
