package com.ssafy.edu.vue.dto;

import java.io.Serializable;

public class Eat implements Serializable {
	String eatid;
	String name;
	String count;
	String memid;
	
	public Eat() {
		super();
	}
	public Eat(String eatid, String name, String count, String memid) {
		super();
		this.eatid = eatid;
		this.name = name;
		this.count = count;
		this.memid = memid;
	}
	public String getEatid() {
		return eatid;
	}
	public void setEatid(String eatid) {
		this.eatid = eatid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getMemid() {
		return memid;
	}
	public void setMemid(String memid) {
		this.memid = memid;
	}
	@Override
	public String toString() {
		return "Eat [eatid=" + eatid + ", name=" + name + ", count=" + count + ", memid=" + memid + "]";
	}
}
