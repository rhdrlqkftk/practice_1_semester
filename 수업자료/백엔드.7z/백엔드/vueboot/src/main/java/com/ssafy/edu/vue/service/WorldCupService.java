package com.ssafy.edu.vue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ssafy.edu.vue.dao.WCupDaoImpl;
import com.ssafy.edu.vue.dto.WorldCup;
@Service
public class WorldCupService implements IWorldCupService {
	
	@Autowired
    private WCupDaoImpl wdao;

	@Override
	public List<WorldCup> findAllWorldCups() throws Exception {
		return wdao.findAllWorldCups();
	}

	@Override
	public List<WorldCup> priorQueue() throws Exception{
		return wdao.priorQueue();
	}
	@Override
	public void addWin(String name) throws Exception {
		wdao.addWin(name);
	}
	@Override
	public int totalCount() throws Exception {
		return wdao.totalCount();
	}
	
	
}
