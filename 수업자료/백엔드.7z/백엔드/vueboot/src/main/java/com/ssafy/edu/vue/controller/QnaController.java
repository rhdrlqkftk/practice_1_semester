package com.ssafy.edu.vue.controller;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dto.EmployeeDto;
import com.ssafy.edu.vue.dto.Qna;
import com.ssafy.edu.vue.help.BoolResult;
import com.ssafy.edu.vue.help.NumberResult;
import com.ssafy.edu.vue.service.IQnaService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = {"*"}, maxAge = 6000)             // 크로싱 브라우져,... 
@RestController
@RequestMapping("/api")
@Api(value="SSAFY", description="SSAFY Resouces Management 2019")		//스웨거 
public class QnaController {
	private static final Logger logger = LoggerFactory.getLogger(QnaController.class);
	
	//add  @PathVariable int memId
	@Autowired
	private IQnaService qnaservice;
	@ApiOperation(value = " 새로운 Qna를 입력한다.", response = BoolResult.class)
	@RequestMapping(value = "/addQna", method = RequestMethod.POST)
   	public ResponseEntity<BoolResult> addQna(@RequestBody Qna dd) throws Exception 
	{
   		boolean total = qnaservice.saveQna(dd);;
   		BoolResult nr=new BoolResult();
   		if (!total) {
			return new ResponseEntity<BoolResult>(HttpStatus.NO_CONTENT);
		}
   		nr.setState("succ");
   		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
   	}
	@ApiOperation(value = "해당 댓글을 반환한다.", response = List.class)
	@RequestMapping(value = "/findQna/{memId}", method = RequestMethod.GET)
	public  ResponseEntity<List<Qna>>index(@PathVariable int memId)throws Exception 
    {
		
		List<Qna> qnas =qnaservice.getQnaList(memId);
		System.out.println(qnas);
		if (qnas .isEmpty()) {
			return new ResponseEntity<List<Qna>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Qna>>(qnas, HttpStatus.OK);
	}
	
	@ApiOperation(value = " 해당메모의 정보를 삭제한다.", response = BoolResult.class)
	@RequestMapping(value = "/deleteQna/{memId}", method = RequestMethod.DELETE)
	public ResponseEntity<BoolResult> deleteqna(@PathVariable int memId) throws Exception{
		logger.debug("Welcome MemberController deletemem! " + new Date());
		
		boolean total = qnaservice.qnadelete(memId);
		BoolResult nr=new BoolResult();
		if (!total) {
			return new ResponseEntity<BoolResult>(HttpStatus.NO_CONTENT);
		}
		nr.setState("succ");
		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
	}
    @ApiOperation(value = "상세보기.", response = NumberResult.class)
	@RequestMapping(value = "/Qnadetail/{qnaId}", method = {RequestMethod.GET})
    public ResponseEntity<Qna> Qnadetail(@PathVariable int qnaId) throws Exception
    {
		Qna qn= qnaservice.getQna(qnaId);
		System.out.println(qn);
		if (qn==null || qn.getQnanum()==0) {
			return new ResponseEntity<Qna>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<Qna>(qn, HttpStatus.OK);	
	}
    @ApiOperation(value = " 업뎃.", response = BoolResult.class)
   	@RequestMapping(value = "/updateQna", method = RequestMethod.PUT)
   	public ResponseEntity<BoolResult> updateQna(@RequestBody Qna dd) throws Exception 
	{
    	System.out.println(dd+"adsvjiasjdovisad");
   		boolean total = qnaservice.updateQna(dd);
   		BoolResult nr=new BoolResult();
   		if (!total) {
			return new ResponseEntity<BoolResult>(HttpStatus.NO_CONTENT);
		}
   		nr.setState("succ");
   		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
   	}
	
}
