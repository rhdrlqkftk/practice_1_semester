package com.ssafy.edu.vue.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ssafy.edu.vue.dto.SearchRate;
@Repository
public class SearchRateDaoImpl implements ISearchRateDao {

	String ns = "ssafy.searchrate.";
	@Autowired
	private SqlSession sqlSession; 
	@Override
	public List<SearchRate> getrate(int categori) throws Exception
	{
		return sqlSession.selectList(ns+"getrate", categori);
	}
	@Override
	public void search(String keyword, String index) throws Exception
	{
		// TODO Auto-generated method stub
		Map<String,String> map = new HashMap<>();
		map.put("keyword", keyword);
		map.put("index", index);
		sqlSession.insert(ns+"search", map);
	}
	@Override
	public String getcount(String keyword, String index) throws Exception
	{
		Map<String,String> map = new HashMap<>();
		map.put("keyword", keyword);
		map.put("index", index);
		System.out.println(map+"+++++++++++++++++++++++");
		
		return sqlSession.selectOne(ns+"getcount",map);
	}

	@Override
	public void upcount(String keyword, String index, int count) throws Exception {
		Map<String,String> map = new HashMap<>();
		map.put("keyword", keyword);
		map.put("index", index);
		map.put("count", count+"");
		sqlSession.update(ns+"upcount",map);
	}
}
