package com.ssafy.edu.vue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.edu.vue.dao.MemberDaoImpl;
import com.ssafy.edu.vue.dto.Eat;
import com.ssafy.edu.vue.dto.Member;


@Service
public class MemberService implements IMemberService{
	
    @Autowired
	private MemberDaoImpl MemDao;

	@Override
	public boolean SignUp(Member m) throws Exception {
		return MemDao.SignUp(m);
	}

	@Override
	public Member Login(Member m) throws Exception {
		return MemDao.Login(m);
	}

	@Override
	public boolean Modify(Member emp) throws Exception {
		return MemDao.Modify(emp);
	}
	@Override
	public List<Member> findAllMembers() throws Exception {
		return MemDao.findAllMembers();
	}
	@Override
	public List<Eat> eatfoods(String id) throws Exception {
		// TODO Auto-generated method stub
		return MemDao.eatfoods(id);
	}

	@Override
	public void eatfood(String id, String code, String count) throws Exception {
		MemDao.eatfood(id, code, count);
	}
	
	
   /* @Override
	@Transactional(readOnly=true)
	public List<EmployeeDto> findAllEmployees() throws Exception {
		return employeeDao.findAllEmployees();
	}
    
    @Override
	@Transactional(readOnly=true)
	public int getEmployeesTotal() throws Exception {
		return employeeDao.getEmployeesTotal();
	}

    @Override
	@Transactional(readOnly=true)
	public List<EmployeeDto> findLikeEmployees(String name) throws Exception {
    	return employeeDao.findLikeEmployees(name);
	}

	@Override
	@Transactional
	public int addEmployee(EmployeeDto emp) throws Exception {
		//나중에 auto로 바꾸기
		emp.setId(employeeDao.findAfterAdd()+1);
		employeeDao.addEmployee(emp);
		return employeeDao.findAfterAdd();
	}

	@Override
	@Transactional(readOnly=true)
	public List<DepartmentDto> findAllDepartments() throws Exception {
		return employeeDao.findAllDepartments();
	}

	@Override
	@Transactional(readOnly=true)
	public List<EmployeeDto> findAllTitles() throws Exception {
		return employeeDao.findAllTitles();
	}

	@Override
	@Transactional(readOnly=true)
	public EmployeeDto findEmployeeById(int id) throws Exception {
		return employeeDao.findEmployeeById(id);
	}


	@Override
	@Transactional
	public boolean deleteEmployee(int id) throws Exception {
		return employeeDao.deleteEmployee(id);
	}*/

	
}
