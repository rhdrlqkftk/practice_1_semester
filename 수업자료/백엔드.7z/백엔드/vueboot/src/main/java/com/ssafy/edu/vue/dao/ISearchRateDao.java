package com.ssafy.edu.vue.dao;

import java.util.List;

import com.ssafy.edu.vue.dto.SearchRate;


public interface ISearchRateDao {
	public List<SearchRate> getrate(int categori)throws Exception;
 	public void search(String keyword, String index)throws Exception;
	public String getcount(String keyword, String index)throws Exception;
	public void upcount(String keyword, String index, int count)throws Exception;

}
