package com.ssafy.edu.vue.dao;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.ssafy.edu.vue.dto.Food;


@Repository
public class FoodDaoImpl implements IFoodDao {

	String ns="com.ssafy.edu.vue.dao.IFoodDao.";
	@Autowired
	private SqlSession sqlSession;
	@Override
	public List<Food> findAllFoods()throws Exception
	{
		return sqlSession.selectList(ns+"findAllFoods");
	}
	public Food findFoodById(String id) {
		return sqlSession.selectOne(ns+"findFoodById",id);
	}
	@Override
	public List<Food> searchFoods(String name) {
		return sqlSession.selectList(ns+"searchFoods",name);
	}

}
