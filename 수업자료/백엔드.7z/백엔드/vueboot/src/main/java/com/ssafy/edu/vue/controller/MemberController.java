package com.ssafy.edu.vue.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dto.Eat;
import com.ssafy.edu.vue.dto.EmployeeDto;
import com.ssafy.edu.vue.dto.Food;
import com.ssafy.edu.vue.dto.Member;
import com.ssafy.edu.vue.help.BoolResult;
import com.ssafy.edu.vue.service.IMemberService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

//http://localhost:8197/humans/swagger-ui.html
@CrossOrigin(origins = {"*"}, maxAge = 6000)             // 크로싱 브라우져,... 
@RestController
@RequestMapping("/api")
@Api(value="SSAFY", description="SSAFY Resouces Management 2019")		//스웨거
public class MemberController 
{
	private static final Logger logger = 
			LoggerFactory.getLogger(MemberController.class);
	
	@Autowired
	private IMemberService memservice;
	@ApiOperation(value = "모든 멤버정보.", response = List.class)
	@RequestMapping(value = "/findAllMembers", method = RequestMethod.GET)
	public ResponseEntity<List<Member>> findAllMembers() throws Exception {
		logger.info("1-------------findAllEmployees-----------------------------"+new Date());
		List<Member> ps = memservice.findAllMembers();
		if (ps.isEmpty()) {
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Member>>(ps, HttpStatus.OK);
	}

	
	@ApiOperation(value = "로그인 합니다.", response = BoolResult.class)
	@RequestMapping(value = "/Login", method = RequestMethod.POST)
	public ResponseEntity<Member> Login(@RequestBody Member dto) throws Exception {
		
		logger.debug("Welcome MemberController login! " + new Date());
		Member gg =memservice.Login(dto);
		if (gg==null) 
		{
			return new ResponseEntity<Member>(HttpStatus.NO_CONTENT);
		}
		System.out.println(gg);
		return new ResponseEntity<Member>(gg, HttpStatus.OK);
	}
	@ApiOperation(value = "회원수정 합니다.", response = BoolResult.class)
	@RequestMapping(value = "/Modify", method = RequestMethod.PUT)
	public ResponseEntity<BoolResult> modify(@RequestBody Member m) 
	{
		logger.debug("Welcome MemberController modify! " + new Date());
		BoolResult nr=new BoolResult();
		System.out.println(m);
   		try
   		{
   			boolean total = memservice.Modify(m);
   		}
   		catch (Exception e) 
   		{
	   			return new ResponseEntity<BoolResult>(HttpStatus.NO_CONTENT);
   		}
   		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
	}

	@ApiOperation(value = "회원가입 합니다.", response = BoolResult.class)
	@RequestMapping(value = "/SignUp", method = RequestMethod.POST)
	public ResponseEntity<BoolResult> signup(@RequestBody Member m) throws Exception 
	{
		BoolResult nr=new BoolResult();
   		try
   		{
   			boolean total = memservice.SignUp(m);
   			
   		}
   		catch (Exception e) {
   	   			return new ResponseEntity<BoolResult>(HttpStatus.NO_CONTENT);
		}
   		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
	}
	
	@ApiOperation(value = "섭취목록", response = List.class)
	@RequestMapping(value = "/findAllEat/{id}", method = RequestMethod.GET)
	public ResponseEntity<List<Eat>>findAllEat(@PathVariable String id) throws Exception 
	{
		logger.debug("Welcome FoodController index! " + new Date());
		List<Eat> foods= memservice.eatfoods(id);
		if (foods.isEmpty()) {
			return new ResponseEntity<List<Eat>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Eat>>(foods, HttpStatus.OK);
	}
	
	
	@ApiOperation(value = "섭취하기", response =  BoolResult.class)
	@RequestMapping(value = "/EatFood/{id}/{count}/{code}", method = RequestMethod.GET)
	public void eatlist(@PathVariable String id,@PathVariable String count , @PathVariable String code)throws Exception
	{
		memservice.eatfood(id, code, count);
	}	
/*	@RequestMapping(value = "eat.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String eat(HttpServletRequest request,String count, String code,Model model) {
		logger.debug("Welcome MemberController eat! " + new Date());
		HttpSession session=request.getSession();
		String id=(String) session.getAttribute("id");
		memservice.eatfood(id, code, count);
		
		return "safefood";
	}
	
*/	
	/*
	@RequestMapping(value = "selfinfo.do", method = RequestMethod.POST)
	@ResponseBody
	public Member selfinfo(String id,Model model) {
		logger.debug("Welcome MemberController selfinfo! " + new Date());
		Member m =  memservice.findMemberById(id);
		
		return m;
	}//
	//
	@RequestMapping(value = "deletemem.do", method = RequestMethod.GET)
	public String deletemem(String id,Model model) {
		logger.debug("Welcome MemberController deletemem! " + new Date());
		memservice.deleteMyself(id);
		return "redirect:/logout.do";
	}//memberlist.do
	@RequestMapping(value = "memberlist.do", method = RequestMethod.GET)
	public String memberlist(String id,Model model) {
		logger.debug("Welcome MemberController memberlist! " + new Date());
		model.addAttribute("mlist", memservice.findMembers());
		return "memlist";
	}//memberlist.do
	
	
	
*/
//	@RequestMapping(value = "login.do", 
//			method = RequestMethod.POST)
//	@ResponseBody
//	public String books(Model model) {
//		logger.debug("Welcome MainController books! "+ new Date());
//		//return "forward:/index";
//		model.addAttribute("books", bookservice.getBookList());
//		return "books";
//	}//	
//	@RequestMapping(value = "books2.do", 
//			method = RequestMethod.GET)
//	public String books2(BookSearch bs, Model model) {
//		logger.debug("Welcome MainController books2! "+ new Date());
//		logger.debug("Welcome MainController books2!----------------------------------- "+ bs);
//		//return "forward:/index";
//		model.addAttribute("books", bookservice.getBookSearch(bs));
//		model.addAttribute("s_category", bs.getS_category());
//		model.addAttribute("s_keyword", bs.getS_keyword());
//		return "books2";
//	}//	
//	@RequestMapping(value = "bookdetail.do", 
//			method = {RequestMethod.GET,RequestMethod.POST})
//	public String bookdetail(String isbn,Model model) {
//		logger.debug("Welcome MainController bookdetail! "+ new Date());
//		//return "forward:/index";
//		Book bbb=bookservice.getBook(isbn);
//		bbb.getIsbn123();
//		logger.debug("Welcome MainController bookdetail! "+ bbb);
//		model.addAttribute("book",bbb );
//		return "bookdetail";
//	}//	
//	@RequestMapping(value = "updatebook.do", 
//			method = RequestMethod.POST)
//	public String updatebook(Book b,Model model) {
//		logger.debug("Welcome MainController updatebook! "+ new Date());
//		String isbn=String.format("%s-%s-%s", b.getIsbn1(),b.getIsbn2(),b.getIsbn3());
//		b.setIsbn(isbn);
//		bookservice.updatebook(b);
//		return "redirect:/bookdetail.do?isbn="+isbn;
//	}//	
//	@RequestMapping(value = "savebook.do", 
//			method = RequestMethod.POST)
//	public String savebook(Book b,Model model) {
//		logger.debug("Welcome MainController savebook! "+ new Date());
//		String isbn=String.format("%s-%s-%s", b.getIsbn1(),b.getIsbn2(),b.getIsbn3());
//		b.setIsbn(isbn);
//		bookservice.savebook(b);
//		return "redirect:/books.do";
//	}//	
//
//	@RequestMapping(value = "addbook.do", 
//			method = RequestMethod.GET)
//	public String addbook(Model model) {
//		logger.debug("Welcome MainController addbook! "+ new Date());
//		return "addbook";
//	}//	

}
