package com.ssafy.edu.vue.controller;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dto.Qna;
import com.ssafy.edu.vue.dto.SearchRate;
import com.ssafy.edu.vue.help.BoolResult;
import com.ssafy.edu.vue.service.ISearchRateService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
@CrossOrigin(origins = {"*"}, maxAge = 6000)             // 크로싱 브라우져,... 
@RestController
@RequestMapping("/api")
@Api(value="SSAFY", description="SSAFY Resouces Management 2019")		//스웨거 
public class RateController {
	private static final Logger logger = LoggerFactory.getLogger(RateController.class);
	@Autowired
	private ISearchRateService rateservice;
	
	@ApiOperation(value = "rate", response = List.class)
	@RequestMapping(value = "/rate/{dd}", method = RequestMethod.GET)
   	public ResponseEntity<List<SearchRate>> rate(@PathVariable int dd) throws Exception 
	{
   		List<SearchRate> srs = rateservice.getrate(dd);
   		if (srs.isEmpty()){
			return new ResponseEntity<List<SearchRate>>(HttpStatus.NO_CONTENT);
		}
   		return new ResponseEntity<List<SearchRate>>(srs, HttpStatus.OK);
   	}
	@ApiOperation(value = "search", response =  BoolResult.class)
	@RequestMapping(value = "/search/{keyword}/{index}", method = RequestMethod.PUT)
	public ResponseEntity<BoolResult> search(@PathVariable String keyword , @PathVariable String index)throws Exception 
	{
		String num = rateservice.getcount(keyword, index);
		BoolResult nr=new BoolResult();
		if(num == null) 
		{
			rateservice.search(keyword,index);			
		}
		else 
		{
			int intnum = Integer.parseInt(num);
			rateservice.upcount(keyword,index,intnum+1);
		}
		return new ResponseEntity<BoolResult>(nr, HttpStatus.OK);
	}

}
