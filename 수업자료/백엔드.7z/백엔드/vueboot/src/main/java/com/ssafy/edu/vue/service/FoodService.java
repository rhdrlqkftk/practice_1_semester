package com.ssafy.edu.vue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.edu.vue.dao.FoodDaoImpl;
import com.ssafy.edu.vue.dto.Food;

@Service
public class FoodService implements IFoodService {
	
	@Autowired
    private FoodDaoImpl fooddao;
	
	@Override
	@Transactional(readOnly=true)
	public List<Food> findAllFoods()  throws Exception{
		return fooddao.findAllFoods();
	}
	@Override
	@Transactional(readOnly=true)
	public Food findFoodById(String id) throws Exception{
		return fooddao.findFoodById(id);
	}	
	@Override
	@Transactional(readOnly=true)
	public List<Food> searchFoods(String name){
		return fooddao.searchFoods(name);
	}
}
