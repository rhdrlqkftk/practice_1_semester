package com.ssafy.edu.vue.dto;

public class SearchRate {
	String content;
	int count;
	int categori;
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getCategori() {
		return categori;
	}
	public void setCategori(int categori) {
		this.categori = categori;
	}
	@Override
	public String toString() {
		return "SearchRate [content=" + content + ", count=" + count + ", categori=" + categori + "]";
	}
	public SearchRate(String content, int count, int categori) {
		super();
		this.content = content;
		this.count = count;
		this.categori = categori;
	}
	public SearchRate() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
}
