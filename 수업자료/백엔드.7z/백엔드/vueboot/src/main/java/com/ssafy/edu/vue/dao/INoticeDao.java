package com.ssafy.edu.vue.dao;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import com.ssafy.edu.vue.dto.Notice;

@Mapper
public interface INoticeDao {
	public List<Notice> getNoticeList ()throws Exception;
	public Notice getNotice(int num)throws Exception;
	public void noticedelete(int id)throws Exception;
	public boolean savenotice(Notice b)throws Exception;
	public boolean updatenotice(Notice b)throws Exception;
	public List<Notice> getByname(String name)throws Exception;
	public List<Notice> getByTitle(String title)throws Exception;
}
