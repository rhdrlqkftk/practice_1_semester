package com.ssafy.edu.vue.dao;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.edu.vue.dto.Qna;
@Repository
public class QnaDaoImpl implements IQnaDao {

	String ns="com.ssafy.edu.vue.dao.IQnaDao.";	
	@Autowired
	private SqlSession sqlSession;	
	
	@Override
	public boolean saveQna(Qna b) throws Exception{
		sqlSession.insert(ns+"saveQna",b);
		return true;
	}
	@Override
	public List<Qna> getQnaList(int memid)throws Exception{
		return sqlSession.selectList(ns+"getQnaList",memid);
	}
	@Override
	public Qna getQna(int num) throws Exception
	{
		return sqlSession.selectOne(ns+"getQna",num);
	}
	@Override
	public boolean qnadelete(int Id) {
		System.out.println(Id + " disjdifjais");
		sqlSession.delete(ns+"qnadelete",Id);
		return true;
	}
	@Override
	public boolean qnadelete2(int Id) {
		System.out.println(Id);
		sqlSession.delete(ns+"qnadelete2",Id);
		return true;
	}
	
	
	public boolean updateQna(Qna b) {
		System.out.println(b+"zzz");
		sqlSession.update(ns+"updateQna",b);
		return true;
	}
	/*
	public boolean Qnadelete(int num) throws Exception {
		sqlSession.delete(ns+"Qnadelete",num);
		return true;
	}
	*/
	
	
}
