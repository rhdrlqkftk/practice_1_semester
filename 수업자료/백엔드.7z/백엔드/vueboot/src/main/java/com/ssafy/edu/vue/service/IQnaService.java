package com.ssafy.edu.vue.service;

import java.util.List;

import com.ssafy.edu.vue.dto.Qna;

public interface IQnaService {
	
	public List<Qna> getQnaList(int memid)throws Exception;
	public Qna getQna(int num) throws Exception;
	public boolean saveQna(Qna b) throws Exception;
	public boolean qnadelete(int Id)throws Exception;
	public boolean updateQna(Qna b)throws Exception;
	public boolean qnadelete2(int Id) throws Exception;

/*	
	public boolean Qnadelete(int num) throws Exception;
	
*/	
}
