package com.ssafy.edu.vue.service;

import java.util.List;

import com.ssafy.edu.vue.dto.Notice;

public interface INoticeService {
	
	public List<Notice> getNoticeList ()throws Exception;
	public Notice getNotice(int num)throws Exception ;
	public void noticedelete(int id) throws Exception;
	public boolean updatenotice(Notice b);
	public boolean savenotice(Notice b)throws Exception;
	List<Notice> getByname(String name) throws Exception;
	List<Notice> getByTitle(String title) throws Exception;
}
