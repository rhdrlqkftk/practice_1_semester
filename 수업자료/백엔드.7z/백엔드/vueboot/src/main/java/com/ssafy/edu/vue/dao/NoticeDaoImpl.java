package com.ssafy.edu.vue.dao;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.edu.vue.dto.Notice;
@Repository
public class NoticeDaoImpl implements INoticeDao {

	String ns="com.ssafy.edu.vue.dao.INoticeDao.";
	
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<Notice> getNoticeList ()throws Exception{
		return sqlSession.selectList(ns+"getNoticeList");
	}
	@Override
	public Notice getNotice(int num) throws Exception{
		return sqlSession.selectOne(ns+"getNotice",num);
	}
	@Override
	public void noticedelete(int id) throws Exception {
		System.out.println(id+"ascjsacijcsiasacj");
		sqlSession.delete(ns+"noticedelete",id);
	}
	public boolean updatenotice(Notice b) {
		System.out.println(b);
		sqlSession.update(ns+"updatenotice",b);
		return true;
	}
	@Override
	public boolean savenotice(Notice b) throws Exception{
		sqlSession.insert(ns+"savenotice",b);
		return true;
	}
	public List<Notice> getByname(String name) {
		return sqlSession.selectList(ns+"getByname", name);
	}
	public List<Notice> getByTitle(String title) {
		return sqlSession.selectList(ns+"getByTitle", title);
	}
}
