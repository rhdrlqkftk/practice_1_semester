package com.ssafy.edu.vue.dto;

public class WorldCup {
	int win; 
	String img; 
	String name;
	public WorldCup() {
		super();
		// TODO Auto-generated constructor stub
	}
	public WorldCup(int win, String img, String name) {
		super();
		this.win = win;
		this.img = img;
		this.name = name;
	}
	public int getWin() {
		return win;
	}
	public void setWin(int win) {
		this.win = win;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
