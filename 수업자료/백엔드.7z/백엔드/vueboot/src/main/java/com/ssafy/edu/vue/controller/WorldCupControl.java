package com.ssafy.edu.vue.controller;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.edu.vue.dto.Notice;
import com.ssafy.edu.vue.dto.WorldCup;
import com.ssafy.edu.vue.help.BoolResult;
import com.ssafy.edu.vue.help.NumberResult;
import com.ssafy.edu.vue.service.INoticeService;
import com.ssafy.edu.vue.service.IWorldCupService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = {"*"}, maxAge = 6000)             // 크로싱 브라우져,... 
@RestController
@RequestMapping("/api")
@Api(value="SSAFY", description="SSAFY Resouces Management 2019")		//스웨거 
public class WorldCupControl {
	private static final Logger logger = LoggerFactory.getLogger(WorldCupControl.class);

	@Autowired
	private IWorldCupService cupservice;
	
    @ApiOperation(value = "모든 음식을 랜덤으로 가져옵니다.", response = List.class)
	@RequestMapping(value = "/findAllWorldCups", method = RequestMethod.GET)
	public  ResponseEntity<List<WorldCup>> Cupindex()throws Exception 
    {
		List<WorldCup> worlds = cupservice.findAllWorldCups();
		if (worlds.isEmpty()) {
			return new ResponseEntity<List<WorldCup>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<WorldCup>>(worlds, HttpStatus.OK);
	}
    @ApiOperation(value = "인기많은 순으로 음식을 가져옵니다.", response = List.class)
	@RequestMapping(value = "/PriorityQueue", method = RequestMethod.GET)
	public  ResponseEntity<List<WorldCup>> PriorityQueue()throws Exception 
    {
		List<WorldCup> worlds = cupservice.priorQueue();
		if (worlds.isEmpty()) {
			return new ResponseEntity<List<WorldCup>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<WorldCup>>(worlds, HttpStatus.OK);
	}
    @ApiOperation(value = "승리음식을 추가합니다.")
	@RequestMapping(value = "/AddWin/{name}", method = RequestMethod.PUT)
	public void AddWin(@PathVariable String name)throws Exception 
    {
    	cupservice.addWin(name);
	}
    @ApiOperation(value = "총 횟수", response = Integer.class)
	@RequestMapping(value = "/TotalCount", method = RequestMethod.GET)
	public int TotalCount()throws Exception 
    {
    	int num = cupservice.totalCount();
    	return num;
	}
    
	/*
	@RequestMapping(value = "addnotice.do", 
			method = RequestMethod.GET)
	public String addnotice(Model model) {
		return "addnotice";
	}*/
	
	/*@RequestMapping(value = "savenotice.do", 
			method = RequestMethod.POST)
		public String savenotice(Notice b,Model model) {
		logger.info("Welcome NoticeController savenotice! "+ new Date());
		logger.info("Welcome NoticeController savenotice! "+ b);
		System.out.println(b);
		noticeservice.savenotice(b);
		return "redirect:/notice.do";
	}*/
	
	
}
