package com.ssafy.edu.vue.dto;
import java.io.Serializable;
public class Notice implements Serializable {
	int noticenum; 
	String title; 
	String writer; 
	String content;
	public Notice() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Notice(int noticenum, String title, String writer, String content) {
		super();
		this.noticenum = noticenum;
		this.title = title;
		this.writer = writer;
		this.content = content;
	}
	
	public int getNoticenum() {
		return noticenum;
	}
	public void setNoticenum(int noticenum) {
		this.noticenum = noticenum;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	@Override
	public String toString() {
		return "Notice [noticenum=" + noticenum + ", title=" + title + ", writer=" + writer + ", content=" + content
				+ "]";
	}
}
