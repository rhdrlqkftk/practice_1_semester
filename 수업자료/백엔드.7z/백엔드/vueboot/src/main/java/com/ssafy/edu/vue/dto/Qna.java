package com.ssafy.edu.vue.dto;
import java.io.Serializable;
public class Qna implements Serializable {
	int qnanum; 
	int noticenum;
	String writer; 
	String content;
	
	public Qna() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Qna(int qnanum, int noticenum, String writer, String content) {
		this.qnanum = qnanum;
		this.noticenum = noticenum;
		this.writer = writer;
		this.content = content;
	}
	public Qna(int noticenum, String writer, String content) {
		this.noticenum = noticenum;
		this.writer = writer;
		this.content = content;
	}
	public int getQnanum() {
		return qnanum;
	}
	public void setQnanum(int qnanum) {
		this.qnanum = qnanum;
	}
	public int getNoticenum() {
		return noticenum;
	}
	public void setNoticenum(int noticenum) {
		this.noticenum = noticenum;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	@Override
	public String toString() {
		return "Qna [qnanum=" + qnanum + ", noticenum=" + noticenum + ", writer=" + writer + ", content=" + content
				+ "]";
	}
	

}
