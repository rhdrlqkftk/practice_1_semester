package com.ssafy.edu.vue.service;

import java.util.List;

import com.ssafy.edu.vue.dto.Food;


public interface IFoodService {
	
	public List<Food> findAllFoods()  throws Exception;
	public Food findFoodById(String id) throws Exception;
	public List<Food> searchFoods(String name) throws Exception;
	

	
}
