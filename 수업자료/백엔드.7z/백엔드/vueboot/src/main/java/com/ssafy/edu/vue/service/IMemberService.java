package com.ssafy.edu.vue.service;


import java.util.List;

import com.ssafy.edu.vue.dto.Eat;
import com.ssafy.edu.vue.dto.Member;
public interface IMemberService {
	
	public boolean SignUp(Member m) throws Exception;
	public Member Login(Member m) throws Exception;
	public boolean Modify(Member emp) throws Exception;
	public List<Member> findAllMembers()throws Exception;
	public List<Eat> eatfoods(String id)throws Exception;
	public void eatfood(String id, String code,String count)throws Exception;
	
	/*	
	public Member findEmployeeById(int id) throws Exception;
	public int getEmployeesTotal()throws Exception;
	public List<Member> findLikeEmployees(String name) throws Exception;
	public int addEmployee(Member emp) throws Exception;
	public List<DepartmentDto> findAllDepartments() throws Exception;
	public List<Member> findAllTitles() throws Exception;
	public boolean updateEmployee(Member emp) throws Exception;
	public boolean deleteEmployee(int id) throws Exception;
*/



}
