package com.ssafy.edu.vue.dao;
import java.util.List;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.edu.vue.dto.WorldCup;
@Repository
public class WCupDaoImpl implements IWcupDao {

	String ns="com.ssafy.edu.vue.dao.IWcupDao.";
	@Autowired
	private SqlSession sqlSession;
	@Override
	public List<WorldCup> findAllWorldCups()throws Exception
	{
		return sqlSession.selectList(ns+"findAllWorldCups");
	}
	
	public List<WorldCup> priorQueue()throws Exception {
		// TODO Auto-generated method stub
		return sqlSession.selectList(ns+"priorQueue");
	}

	public void addWin(String name) throws Exception{
		sqlSession.update(ns+"addWin",name);
	}

	public int totalCount() throws Exception
	{
		return sqlSession.selectOne(ns+ "totalCount");
	}
}
