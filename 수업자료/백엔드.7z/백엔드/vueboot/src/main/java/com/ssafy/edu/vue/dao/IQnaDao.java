package com.ssafy.edu.vue.dao;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import com.ssafy.edu.vue.dto.Qna;

@Mapper
public interface IQnaDao {
	public List<Qna> getQnaList(int memid)throws Exception;
	
	public Qna getQna(int num)throws Exception;
	
	public boolean saveQna(Qna b)throws Exception;
	public boolean qnadelete(int memId)throws Exception;
	public boolean updateQna(Qna b)throws Exception;
	public boolean qnadelete2(int Id)throws Exception;

	/*	
	 boolean Qnadelete(int num);
	*/


}
