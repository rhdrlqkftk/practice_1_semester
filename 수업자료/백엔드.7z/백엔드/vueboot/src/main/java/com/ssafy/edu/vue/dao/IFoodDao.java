package com.ssafy.edu.vue.dao;

import java.util.List;

import com.ssafy.edu.vue.dto.Food;

public interface IFoodDao {
	List<Food> findAllFoods()throws Exception;
	Food findFoodById(String id)throws Exception;
	List<Food> searchFoods(String name);

}
