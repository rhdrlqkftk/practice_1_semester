package com.ssafy.edu.vue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.edu.vue.dao.NoticeDaoImpl;
import com.ssafy.edu.vue.dto.Notice;


@Service
public class NoticeService implements INoticeService {
	
    @Autowired
	private NoticeDaoImpl noticedao;
	
    @Override
	@Transactional(readOnly=true)
	public List<Notice> getByname(String name) throws Exception{
		return noticedao.getByname(name);
	}
    
	@Override
	@Transactional(readOnly=true)
	public List<Notice> getNoticeList() throws Exception{
		return noticedao.getNoticeList();
	}

	@Override
	@Transactional(readOnly=true)
	public Notice getNotice(int num) throws Exception{
		return noticedao.getNotice(num);
	}
	@Override
	@Transactional
	public void noticedelete(int id) throws Exception {
		System.out.println("step3-2");
		noticedao.noticedelete(id);
	}

	@Override
	public boolean savenotice(Notice b) throws Exception {
		return noticedao.savenotice(b);
		
	}
	
	@Override
	@Transactional
	public boolean updatenotice(Notice b) {
		return noticedao.updatenotice(b);
	}
	
	@Override
	@Transactional(readOnly=true)
	public List<Notice> getByTitle(String title) throws Exception{
		return noticedao.getByTitle(title);
	}
	
}
