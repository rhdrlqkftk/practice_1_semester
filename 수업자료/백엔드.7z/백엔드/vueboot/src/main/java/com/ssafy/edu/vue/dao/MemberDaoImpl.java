package com.ssafy.edu.vue.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.edu.vue.dto.Eat;
import com.ssafy.edu.vue.dto.Member;
@Repository
public class MemberDaoImpl implements IMemberDao{
	
    private String ns="com.ssafy.edu.vue.dao.IMemberDao.";
	@Autowired
	private SqlSession sqlSession;
	@Override
	public boolean SignUp(Member m) throws Exception {
		sqlSession.insert(ns +"SignUp", m);
		return true;
	}
	@Override
	public Member Login(Member m) throws Exception {
		return sqlSession.selectOne(ns +"Login", m);
	}
	@Override
	public boolean Modify(Member emp) {
		 sqlSession.selectOne(ns +"Modify", emp);
		 return true;
	}
	@Override
	public List<Member> findAllMembers() throws Exception {
		return sqlSession.selectList(ns+"findAllMembers");
	}
	@Override
	public List<Eat> eatfoods(String id)throws Exception 
	{
		return sqlSession.selectList(ns+"eatfoods", id);
	}
	public void eatfood(String id, String code, String count) {
		Map<String,String> map = new HashMap<>();
		map.put("id", id);
		map.put("code", code);
		map.put("count", count);
		sqlSession.insert(ns+"eatfood",map);
	}
}
