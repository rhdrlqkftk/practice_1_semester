package com.ssafy.edu.vue.dao;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;

import com.ssafy.edu.vue.dto.Eat;
import com.ssafy.edu.vue.dto.Member;
@Mapper
public interface IMemberDao {
	public boolean SignUp(Member m)throws Exception;
	public Member Login(Member m)throws Exception;
	public boolean Modify(Member emp)throws Exception;	
	public List<Member> findAllMembers() throws Exception;
	public List<Eat> eatfoods(String id) throws Exception;
	/*
	public EmployeeDto findEmployeeById(int id) throws Exception;
	public  int getEmployeesTotal()throws Exception;
	public List<EmployeeDto> findLikeEmployees(String name) throws Exception;
	public void addEmployee(EmployeeDto emp) throws Exception;
	public List<DepartmentDto> findAllDepartments() throws Exception;
	public int findAfterAdd() throws Exception;
	public boolean updateEmployee(EmployeeDto emp) throws Exception;
	public boolean deleteEmployee(int id) throws Exception;	*/
	
}
